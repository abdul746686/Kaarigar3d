# Boycott Alert App
An Android app that listens for boycott-related brand names using speech recognition and alerts the user.
